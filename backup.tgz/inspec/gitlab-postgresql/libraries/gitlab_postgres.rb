require "shellwords"

# class Lines
#     attr_reader :output

#     def initialize(raw, desc)
#     @output = raw
#     @desc = desc
#     end

#     def lines
#     output.split("\n").map(&:strip)
#     end

#     def to_s
#     @desc
#     end
# end

class PostgresSession < Inspec.resource(1)
    name "gitlab_postgres"
    supports platforms: "ubuntu"
    supports platform: 'almalinux'

    desc "connect to gitlab postgres and run queries"
    example <<-EXAMPLE
        sql = gitlab_postgres('username', 'host', 'port')
        query('sql_query', ['database_name'])

        describe sql.query('SELECT * FROM pg_shadow WHERE passwd IS NULL;') do
            its('output') { should eq '' }
        end
    EXAMPLE

    def initialize(user, host = nil, port)
        @user = user || "gitlab-psql"
        @host = host || "/var/opt/gitlab/posgresql"
        @port = port || "5432"
        # @socket = socket || "/var/opt/gitlab/postgresql/.s.PGSQL.5432"
    end

    def query(query, db = [])
        psql_cmd = create_psql_cmd(query, db)
        # TODO adjust command to run as gitlab-psql
        inspec.command(psql_cmd)
        # TODO improve error output
        # cmd = inspec.command(psql_cmd, redact_regex: /(PGPASSWORD=').+(' psql .*)/)
        # out = cmd.stdout + "\n" + cmd.stderr
        # if cmd.exit_status != 0 || out =~ /could not connect to .*/ || out.downcase =~ /^error:.*/
        #     Lines.new(out, "PostgreSQL query with errors: #{query}")
        # else
        #     Lines.new(cmd.stdout.strip, "PostgreSQL query: #{query}")
        # end
    end

    private

    def escape_string(query)
        Shellwords.escape(query)
    end

    def create_psql_cmd(query, db = [])
        "sudo gitlab-psql #{@user} -A -t -c #{escape_string(query)} #{db}"
    end
end