require "shellwords"

class TestResrouce < Inspec.resource(1)
    name "test_resource"

    supports platform: 'ubuntu'
    supports platform: 'almalinux'

    desc 'Test custom resource'

    def initialize(user = nil)
        @user = user || "gitlab-psql"
    end

    def echo(cmd)
        inspec.command("sudo gitlab-psql gitlab-psql -t -A -c 'SHOW max_connections;'")
    end

    def query(query)
        psql_cmd = psql_cmd(query)
        inspec.command(psql_cmd)
    end

    private

    def escape_string(query)
        Shellwords.escape(query)
    end

    def psql_cmd(query)
        "sudo gitlab-psql #{@user} -t -A -c #{escape_string(query)}"
    end
end