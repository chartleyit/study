control "V-261926" do
    title "SRG-APP-000383-DB-000364"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'As the database administrator, run the following SQL:

$ psql -c "SHOW port"

If the currently defined port configuration is deemed prohibited, this is a finding.'

    desc 'fix', 'Note: The following instructions use the PGDATA and PGVER environment variables. Refer to APPENDIX-F for instructions on configuring PGDATA and APPENDIX-H for PGVER.

    To change the listening port of the database, as the database administrator, change the following setting in postgresql.conf: 

    $ sudo su - postgres 
    $ vi $PGDATA/postgresql.conf 

    Change the port parameter to the desired port. 

    Restart the database: 

    $ sudo systemctl restart postgresql-${PGVER?} 

    Note: psql uses the port 5432 by default. This can be changed by specifying the port with psql or by setting the PGPORT environment variable: 

    $ psql -p 5432 -c "SHOW port" 
    $ export PGPORT=5432'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000383-DB-000364"
    tag gid: "V-261926"
    tag rid: "SV-261926r1000783_rule"
    tag stig_id: "CD16-00-008000"
    tag fix_id: "F-65688r1000782_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Use of nonsecure network functions, ports, protocols, and services exposes the system to avoidable threats.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end