control "V-261857" do
    title "SRG-APP-000001-DB-000031"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'To check the total amount of connections allowed by the database, as the database administrator, run the following SQL:

$ sudo su - postgres
$ psql -c "SHOW max_connections"

If the total amount of connections is greater than documented by an organization, this is a finding.

To check the amount of connections allowed for each role, as the database administrator, run the following SQL:

$ sudo su - postgres
$ psql -c "SELECT rolname, rolconnlimit 
FROM pg_roles
WHERE rolname NOT IN (
'"'"'pg_database_owner'"'"',
'"'"'pg_read_all_data'"'"',
'"'"'pg_write_all_data'"'"',
'"'"'pg_monitor'"'"',
'"'"'pg_read_all_settings'"'"',
'"'"'pg_read_all_stats'"'"',
'"'"'pg_stat_scan_tables'"'"',
'"'"'pg_read_server_files'"'"',
'"'"'pg_write_server_files'"'"',
'"'"'pg_execute_server_program'"'"',
'"'"'pg_signal_backend'"'"',
'"'"'pg_checkpoint'"'"',
'"'"'pg_use_reserved_connections'"'"',
'"'"'pg_create_subscription'"'"');"

If any roles have more connections configured than documented, this is a finding. A value of "-1" indicates Unlimited and is a finding.'

    desc 'fix', 'Note: The following instructions use the PGDATA and PGVER environment variables. Refer to APPENDIX-F for instructions on configuring PGDATA and APPENDIX-H for PGVER.

    To configure the maximum amount of connections allowed to the database, as the database administrator (shown here as "postgres") change the following in postgresql.conf (the value 10 is an example; set the value to suit local conditions):

    $ sudo su - postgres 
    $ vi ${PGDATA?}/postgresql.conf 
    max_connections = 10 

    Restart the database:

    $ sudo systemctl restart postgresql-${PGVER?}

    To limit the amount of connections allowed by a specific role, as the database administrator, run the following SQL: 

    $ psql -c "ALTER ROLE <rolname> CONNECTION LIMIT 1";'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000001-DB-000031"
    tag gid: "V-261857"
    tag rid: "SV-261857r1000976_rule"
    tag stig_id: "CD16-00-000100"
    tag fix_id: "F-65619r1000575_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Database management includes the ability to control the number of users and user sessions using PostgreSQL. Unlimited concurrent connections to PostgreSQL could allow a successful denial-of-service (DoS) attack by exhausting connection resources; and a system can also fail or be degraded by an overload of legitimate users. Limiting the number of concurrent sessions per user is helpful in reducing these risks.

    This requirement addresses concurrent session control for a single account. It does not address concurrent sessions by a single user via multiple system accounts; and it does not deal with the total number of sessions across all accounts.

    The capability to limit the number of concurrent sessions per user must be configured in or added to PostgreSQL (for example, by use of a log on trigger), when this is technically feasible. Note that it is not sufficient to limit sessions via a web server or application server alone, because legitimate users and adversaries can potentially connect to PostgreSQL by other means.

    The organization will need to define the maximum number of concurrent sessions by account type, by account, or a combination thereof. In deciding on the appropriate number, it is important to consider the work requirements of the various types of users. For example, two might be an acceptable limit for general users accessing the database via an application; but 10 might be too few for a database administrator using a database management GUI tool, where each query tab and navigation pane may count as a separate session.

    (Sessions may also be referred to as connections or logons, which for the purposes of this requirement are synonyms).</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end