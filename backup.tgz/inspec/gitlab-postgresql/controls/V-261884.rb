control "V-261884" do
    title "SRG-APP-000133-DB-000200"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Review system documentation to identify accounts authorized to own database objects. Review accounts that own objects in the database(s).

If any database objects are found to be owned by users not authorized to own database objects, this is a finding.

To check the ownership of objects in the database, as the database administrator, run the following SQL:

$ sudo su - postgres
$ psql -X -c '"'"'\dnS'"'"'
$ psql -x -c "\dt *.*"
$ psql -X -c '"'"'\dsS'"'"'
$ psql -x -c "\dv *.*"
$ psql -x -c "\df+ *.*"

If any object is not owned by an authorized role for ownership, this is a finding.'

    desc 'fix', 'Assign ownership of authorized objects to authorized object owner accounts.

    #### Schema Owner

    To create a schema owned by the user "bob", run the following SQL:

    $ sudo su - postgres
    $ psql -c "CREATE SCHEMA test AUTHORIZATION bob" 

    To alter the ownership of an existing object to be owned by the user "bob", run the following SQL:

    $ sudo su - postgres
    $ psql -c "ALTER SCHEMA test OWNER TO bob"'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000133-DB-000200"
    tag gid: "V-261884"
    tag rid: "SV-261884r1000657_rule"
    tag stig_id: "CD16-00-002900"
    tag fix_id: "F-65646r1000656_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Within the database, object ownership implies full privileges to the owned object, including the privilege to assign access to the owned objects to other subjects. Database functions and procedures can be coded using definer'"'"'s rights. This allows anyone who uses the object to perform the actions if they were the owner. If not properly managed, this can lead to privileged actions being taken by unauthorized individuals.

    Conversely, if critical tables or other objects rely on unauthorized owner accounts, these objects may be lost when an account is removed.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end