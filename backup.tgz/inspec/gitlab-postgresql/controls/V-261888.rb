control "V-261888" do
    title "SRG-APP-000141-DB-000093"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'PostgreSQL'"'"'s COPY command can interact with the underlying OS. Only superuser has access to this command.

As the database administrator (shown here as "postgres"), run the following SQL to list all roles and their privileges:

$ sudo su - postgres
$ psql -x -c "\du"

If any role has "superuser" that should not, this is a finding.

It is possible for an extension to contain code that could access external executables via SQL. To list all installed extensions, as the database administrator (shown here as "postgres"), run the following SQL:

$ sudo su - postgres
$ psql -x -c "SELECT * FROM pg_available_extensions WHERE installed_version IS NOT NULL"

If any installed extensions are not approved, this is a finding.'

    desc 'fix', 'To remove superuser from a role, as the database administrator (shown here as "postgres"), run the following SQL:

    $ sudo su - postgres
    $ psql -c "ALTER ROLE <role-name> WITH NOSUPERUSER"

    To remove extensions from PostgreSQL, as the database administrator (shown here as "postgres"), run the following SQL:

    $ sudo su - postgres
    $ psql -c "DROP EXTENSION extension_name"'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000141-DB-000093"
    tag gid: "V-261888"
    tag rid: "SV-261888r1000669_rule"
    tag stig_id: "CD16-00-003400"
    tag fix_id: "F-65650r1000668_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Information systems are capable of providing a wide variety of functions and services. Some of the functions and services, provided by default, may not be necessary to support essential organizational operations (e.g., key missions, functions).

    It is detrimental for applications to provide, or install by default, functionality exceeding requirements or mission objectives.

    Applications must adhere to the principles of least functionality by providing only essential capabilities.

    PostgreSQL may spawn additional external processes to execute procedures that are defined in PostgreSQL but stored in external host files (external procedures). The spawned process used to execute the external procedure may operate within a different OS security context than PostgreSQL and provide unauthorized access to the host system.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end