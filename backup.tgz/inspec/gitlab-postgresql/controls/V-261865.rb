control "V-261865" do
    title "SRG-APP-000092-DB-000208"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'As the database administrator (shown here as "postgres"), check the current settings by running the following SQL: 

$ sudo su - postgres 
$ psql -c "SHOW shared_preload_libraries" 

If pgaudit is not in the current setting, this is a finding. 

As the database administrator (shown here as "postgres"), check the current settings by running the following SQL: 

$ psql -c "SHOW log_destination" 

If stderr or syslog are not in the current setting, this is a finding.'

    desc 'fix', 'Configure PostgreSQL to enable auditing.

    To ensure logging is enabled, review supplementary content APPENDIX-C for instructions on enabling logging.

    For session logging, using pgaudit is recommended. For instructions on how to setup pgaudit, refer to supplementary content APPENDIX-B.'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000092-DB-000208"
    tag gid: "V-261865"
    tag rid: "SV-261865r1000600_rule"
    tag stig_id: "CD16-00-000900"
    tag fix_id: "F-65627r1000599_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Session auditing is for use when a user'"'"'s activities are under investigation. To ensure the capture of all activity during those periods when session auditing is in use, it needs to be in operation for the whole time PostgreSQL is running.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end