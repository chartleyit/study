control "V-261929" do
    title "SRG-APP-000427-DB-000385"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'As the database administrator (shown here as "postgres"), verify the following setting in postgresql.conf:

$ sudo su - postgres
$ psql -c "SHOW ssl_ca_file"
$ psql -c "SHOW ssl_cert_file"

If the database is not configured to use only DOD-approved certificates, this is a finding.'

    desc 'fix', 'Revoke trust in any certificates not issued by a DOD-approved certificate authority.

    Configure PostgreSQL to accept only DOD and DOD-approved PKI end-entity certificates.

    To configure PostgreSQL to accept approved CAs, refer to the official PostgreSQL documentation: http://www.postgresql.org/docs/current/static/ssl-tcp.html

    For more information on configuring PostgreSQL to use SSL, refer to supplementary content APPENDIX-G.'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000427-DB-000385"
    tag gid: "V-261929"
    tag rid: "SV-261929r1000792_rule"
    tag stig_id: "CD16-00-008400"
    tag fix_id: "F-65691r1000791_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Only DOD-approved external PKIs have been evaluated to ensure that they have security controls and identity vetting procedures in place which are sufficient for DOD systems to rely on the identity asserted in the certificate. PKIs lacking sufficient security controls and identity vetting procedures risk being compromised and issuing certificates that enable adversaries to impersonate legitimate users.

    The authoritative list of DOD-approved PKIs is published at https://public.cyber.mil/pki-pke/interoperability/.

    This requirement focuses on communications protection for the PostgreSQL session rather than for the network packet.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end