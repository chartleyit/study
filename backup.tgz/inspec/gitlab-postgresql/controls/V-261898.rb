control "V-261898" do
    title "SRG-APP-000211-DB-000122"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Check PostgreSQL settings and vendor documentation to verify that administrative functionality is separate from user functionality.

As the database administrator (shown here as "postgres"), list all roles and permissions for the database:

$ sudo su - postgres
$ psql -c "\du"

If any nonadministrative role has the attribute "Superuser", "Create role", "Create DB" or "Bypass RLS", this is a finding.

If administrator and general user functionality are not separated either physically or logically, this is a finding.'

    desc 'fix', 'Configure PostgreSQL to separate database administration and general user functionality.

    Do not grant superuser, create role, create db, or bypass rls role attributes to users that do not require it.

    To remove privileges, refer to the following example:

    ALTER ROLE <username> NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000211-DB-000122"
    tag gid: "V-261898"
    tag rid: "SV-261898r1000699_rule"
    tag stig_id: "CD16-00-004600"
    tag fix_id: "F-65660r1000698_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Information system management functionality includes functions necessary to administer databases, network components, workstations, or servers and typically requires privileged user access.

    The separation of user functionality from information system management functionality is either physical or logical and is accomplished by using different computers, different central processing units, different instances of the operating system, different network addresses, combinations of these methods, or other methods, as appropriate.

    An example of this type of separation is observed in web administrative interfaces that use separate authentication methods for users of any other information system resources.

    This may include isolating the administrative interface on a different domain and with additional access controls.

    If administrative functionality or information regarding PostgreSQL management is presented on an interface available for users, information on PostgreSQL settings may be inadvertently made available to the user.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end