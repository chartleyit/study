control "V-261947" do
    title "SRG-APP-000496-DB-000335"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Note: The following instructions use the PGDATA and PGLOG environment variables. Refer to APPENDIX-F for instructions on configuring PGDATA and APPENDIX-I for PGLOG.

As the database administrator (shown here as "postgres"), create a test role by running the following SQL:

$ sudo su - postgres
$ psql -c "CREATE ROLE bob"

To test if audit records are generated from unsuccessful attempts at modifying security objects, run the following SQL:

$ sudo su - postgres
$ psql -c "SET ROLE bob; UPDATE pg_authid SET rolsuper = '"'"'t'"'"' WHERE rolname = '"'"'bob'"'"';"

As the database administrator (shown here as "postgres"), verify the denials were logged:

$ sudo su - postgres
$ cat ${PGDATA?}/${PGLOG?}/<latest_log>
< 2024-03-17 10:34:00.017 EDT bob 56eabf52.b62 postgres: >ERROR: permission denied for relation pg_authid
< 2024-03-17 10:34:00.017 EDT bob 56eabf52.b62 postgres: >STATEMENT: UPDATE pg_authid SET rolsuper = '"'"'t'"'"' WHERE rolname = '"'"'bob'"'"';

If denials are not logged, this is a finding.'

    desc 'fix', 'Configure PostgreSQL to produce audit records when unsuccessful attempts to modify security objects occur.

    Unsuccessful attempts to modify security objects can be logged if logging is enabled. To ensure logging is enabled, review supplementary content APPENDIX-C for instructions on enabling logging.'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000496-DB-000335"
    tag gid: "V-261947"
    tag rid: "SV-261947r1000846_rule"
    tag stig_id: "CD16-00-010300"
    tag fix_id: "F-65709r1000845_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Changes in the database objects (tables, views, procedures, functions) that record and control permissions, privileges, and roles granted to users and roles must be tracked. Without an audit trail, unauthorized changes to the security subsystem could go undetected. The database could be severely compromised or rendered inoperative.

    To aid in diagnosis, it is necessary to keep track of failed attempts in addition to the successful ones.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end