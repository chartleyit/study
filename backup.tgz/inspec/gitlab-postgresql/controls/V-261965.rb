control "V-261965" do
    title "SRG-APP-000514-DB-000382"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'As the system administrator, run the following to ensure FIPS is enabled:

$ cat /proc/sys/crypto/fips_enabled

If fips_enabled is not "1", this is a finding.'

    desc 'fix', 'Configure OpenSSL to be FIPS compliant.

    PostgreSQL uses OpenSSL for cryptographic modules. To configure OpenSSL to be FIPS 140-2 compliant, refer to the official RHEL Documentation: https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/8/html/security_hardening/using-the-system-wide-cryptographic-policies_security-hardening#switching-the-system-to-fips-mode_using-the-system-wide-cryptographic-policies.

    For more information on configuring PostgreSQL to use SSL, refer to supplementary content APPENDIX-G.'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000514-DB-000382"
    tag gid: "V-261965"
    tag rid: "SV-261965r1000964_rule"
    tag stig_id: "CD16-00-012200"
    tag fix_id: "F-65727r1000899_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Use of weak or untested encryption algorithms undermines the purposes of using encryption to protect data. The application must implement cryptographic modules adhering to the higher standards approved by the federal government since this provides assurance they have been tested and validated.

    For detailed information, refer to NIST FIPS Publication 140-3, Security Requirements For Cryptographic Modules. Note that the product'"'"'s cryptographic modules must be validated and certified by NIST as FIPS compliant.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end