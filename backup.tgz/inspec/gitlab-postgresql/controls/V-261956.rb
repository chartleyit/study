control "V-261956" do
    title "SRG-APP-000503-DB-000350"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Note: The following instructions use the PGDATA and PGLOG environment variables. Refer to APPENDIX-F for instructions on configuring PGDATA and APPENDIX-I for PGLOG.

As the database administrator (shown here as "postgres"), check if log_connections is enabled by running the following SQL:

$ sudo su - postgres
$ psql -c "SHOW log_connections"

If log_connections is off, this is a finding.

Verify the logs that the previous connection to the database was logged:

$ sudo su - postgres
$ cat ${PGDATA?}/${PGLOG?}/<latest_log>
< 2024-02-16 15:54:03.934 UTC postgres postgres 56c64b8b.aeb: >LOG: connection authorized: user=postgres database=postgres

If an audit record is not generated each time a user (or other principal) logs on or connects to PostgreSQL, this is a finding.'

    desc 'fix', 'Note: The following instructions use the PGDATA and PGVER environment variables. Refer to APPENDIX-F for instructions on configuring PGDATA and APPENDIX-H for PGVER.

    To ensure logging is enabled, see the instructions in the supplementary content APPENDIX-C.

    If logging is enabled the following configurations must be made to log connections, date/time, username, and session identifier.

    As the database administrator (shown here as "postgres"), edit postgresql.conf:

    $ sudo su - postgres
    $ vi ${PGDATA?}/postgresql.conf

    Edit the following parameters as such:

    log_connections = on
    log_line_prefix = '"'"'< %m %u %d %c: >'"'"'

    Where:
    * %m is the time and date
    * %u is the username
    * %d is the database
    * %c is the session ID for the connection

    As the system administrator, reload the server with the new configuration:

    $ sudo systemctl reload postgresql-${PGVER?}'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000503-DB-000350"
    tag gid: "V-261956"
    tag rid: "SV-261956r1000975_rule"
    tag stig_id: "CD16-00-011200"
    tag fix_id: "F-65718r1000872_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>For completeness of forensic analysis, it is necessary to track who/what (a user or other principal) logs on to PostgreSQL.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end