control "V-261931" do
    title "SRG-APP-000429-DB-000387"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'To check if pgcrypto is installed on PostgreSQL, as a database administrator (shown here as "postgres"), run the following command:

$ sudo su - postgres
$ psql -c "SELECT * FROM pg_available_extensions where name='"'"'pgcrypto'"'"'"

If data in the database requires encryption and pgcrypto is not available, this is a finding.

If a disk or filesystem requires encryption, ask the system owner, database administrator (DBA), and system administrator (SA) to demonstrate the use of filesystem and/or disk-level encryption. If this is required and is not found, this is a finding.'

    desc 'fix', 'Configure PostgreSQL, operating system/file system, and additional software as relevant, to provide the required level of cryptographic protection for information requiring cryptographic protection against disclosure.

    Secure the premises, equipment, and media to provide the required level of physical protection.

    The pgcrypto module provides cryptographic functions for PostgreSQL. Refer to supplementary content APPENDIX-E for documentation on installing pgcrypto.

    With pgcrypto installed, it is possible to insert encrypted data into the database:

    INSERT INTO accounts(username, password) VALUES ('"'"'bob'"'"', crypt('"'"'mypass'"'"', gen_salt('"'"'bf'"'"', 4));'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000429-DB-000387"
    tag gid: "V-261931"
    tag rid: "SV-261931r1000798_rule"
    tag stig_id: "CD16-00-008600"
    tag fix_id: "F-65693r1000797_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>PostgreSQLs handling data requiring "data at rest" protections must employ cryptographic mechanisms to prevent unauthorized disclosure and modification of the information at rest. These cryptographic mechanisms may be native to PostgreSQL or implemented via additional software or operating system/file system settings, as appropriate to the situation.

    Selection of a cryptographic mechanism is based on the need to protect the integrity of organizational information. The strength of the mechanism is commensurate with the security category and/or classification of the information. Organizations have the flexibility to either encrypt all information on storage devices (i.e., full disk encryption) or encrypt specific data structures (e.g., files, records, or fields). 

    The decision whether and what to encrypt rests with the data owner and is also influenced by the physical measures taken to secure the equipment and media on which the information resides.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end