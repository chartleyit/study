control "V-261878" do
    title "SRG-APP-000121-DB-000202"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Note: The following instructions use the PGDATA and PGVER environment variables. Refer to APPENDIX-F for instructions on configuring PGDATA, APPENDIX-H for PGVER, and APPENDIX-I for PGLOG. Only the database owner and superuser can alter configuration of PostgreSQL.

Ensure the PGLOG directory is owned by postgres user and group:

$ sudo su - postgres
$ ls -la ${PGLOG?} 

If PGLOG is not owned by the database owner, this is a finding. 

Ensure the data directory is owned by postgres user and group. 

$ sudo su - postgres
$ ls -la ${PGDATA?}

If PGDATA is not owned by the database owner, this is a finding.

Ensure the pgaudit installation is owned by root:

$ sudo su - postgres
$ ls -la /usr/pgsql-${PGVER?}/share/extension/pgaudit*

If the pgaudit installation is not owned by root, this is a finding.

As the database administrator (shown here as "postgres"), run the following SQL to list all roles and their privileges:

$ sudo su - postgres
$ psql -x -c "\du"

If any role has "superuser" that should not, this is a finding.'

    desc 'fix', 'Note: The following instructions use the PGDATA and PGVER environment variables. Refer to APPENDIX-F for instructions on configuring PGDATA, APPENDIX-H for PGVER and APPENDIX-I for PGLOG.

    If PGLOG or PGDATA are not owned by postgres user and group, configure them as follows: 

    $ sudo chown -R postgres:postgres ${PGDATA?}
    $ sudo chown -R postgres:postgres ${PGLOG?}

    If the pgaudit installation is not owned by root user and group, configure it as follows:

    $ sudo chown -R root:root /usr/pgsql-${PGVER?}/share/extension/pgaudit*

    To remove superuser from a role, as the database administrator (shown here as "postgres"), run the following SQL:

    $ sudo su - postgres
    $ psql -c "ALTER ROLE <role-name> WITH NOSUPERUSER"'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000121-DB-000202"
    tag gid: "V-261878"
    tag rid: "SV-261878r1000958_rule"
    tag stig_id: "CD16-00-002300"
    tag fix_id: "F-65640r1000638_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Protecting audit data also includes identifying and protecting the tools used to view and manipulate log data. 

    Depending upon the log format and application, system and application log tools may provide the only means to manipulate and manage application and system log data. It is, therefore, imperative that access to audit tools be controlled and protected from unauthorized access. 

    Applications providing tools to interface with audit data will leverage user permissions and roles identifying the user accessing the tools and the corresponding rights the user enjoys in order to make access decisions regarding the access to audit tools.

    Audit tools include, but are not limited to, OS-provided audit tools, vendor-provided audit tools, and open-source audit tools needed to successfully view and manipulate audit information system activity and records. 

    If an attacker were to gain access to audit tools, they could analyze audit logs for system weaknesses or weaknesses in the auditing itself. An attacker could also manipulate logs to hide evidence of malicious activity.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end