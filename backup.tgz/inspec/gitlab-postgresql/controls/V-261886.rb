control "V-261886" do
    title "SRG-APP-000141-DB-000091"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'To get a list of all extensions installed, use the following commands:

$ sudo su - postgres
$ psql -c "select * from pg_extension where extname != '"'"'plpgsql'"'"'"

If any extensions exist that are not approved, this is a finding.'

    desc 'fix', 'To remove extensions, use the following commands:

    $ sudo su - postgres
    $ psql -c "DROP EXTENSION <extension_name>"

    Note: Removal of plpgsql is not recommended.'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000141-DB-000091"
    tag gid: "V-261886"
    tag rid: "SV-261886r1000951_rule"
    tag stig_id: "CD16-00-003200"
    tag fix_id: "F-65648r1000951_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Information systems are capable of providing a wide variety of functions and services. Some of the functions and services, provided by default, may not be necessary to support essential organizational operations (e.g., key missions, functions).

    It is detrimental for software products to provide, or install by default, functionality exceeding requirements or mission objectives. 

    PostgreSQL must adhere to the principles of least functionality by providing only essential capabilities.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end