control "V-261951" do
    title "SRG-APP-000499-DB-000331"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Note: The following instructions use the PGDATA and PGLOG environment variables. Refer to APPENDIX-F for instructions on configuring PGDATA and APPENDIX-I for PGLOG.

As the database administrator (shown here as "postgres"), create the roles "joe" and "bob" with LOGIN by running the following SQL:

$ sudo su - postgres
$ psql -c "CREATE ROLE joe LOGIN"
$ psql -c "CREATE ROLE bob LOGIN"

Set current role to "bob" and attempt to alter the role "joe":

$ psql -c "SET ROLE bob; ALTER ROLE joe NOLOGIN;"

As the database administrator (shown here as "postgres"), verify the denials are logged:

$ sudo su - postgres
$ cat ${PGDATA?}/${PGLOG?}/<latest_log>
< 2024-03-17 11:28:10.004 UTC bob 56eacd05.cda postgres: >ERROR: permission denied to alter role
< 2024-03-17 11:28:10.004 UTC bob 56eacd05.cda postgres: >STATEMENT: ALTER ROLE joe;

If audit logs are not generated when unsuccessful attempts to delete privileges/permissions occur, this is a finding.'

    desc 'fix', 'Configure PostgreSQL to produce audit records when unsuccessful attempts to delete privileges occur.

    All denials are logged if logging is enabled. To ensure logging is enabled, review supplementary content APPENDIX-C for instructions on enabling logging.'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000499-DB-000331"
    tag gid: "V-261951"
    tag rid: "SV-261951r1000858_rule"
    tag stig_id: "CD16-00-010700"
    tag fix_id: "F-65713r1000857_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Failed attempts to change the permissions, privileges, and roles granted to users and roles must be tracked. Without an audit trail, unauthorized attempts to elevate or restrict privileges could go undetected.

    In an SQL environment, deleting permissions is typically done via the REVOKE or DENY command.

    To aid in diagnosis, it is necessary to keep track of failed attempts in addition to the successful ones.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end