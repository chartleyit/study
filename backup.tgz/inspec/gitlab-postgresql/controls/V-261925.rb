control "V-261925" do
    title "SRG-APP-000381-DB-000361"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Note: The following instructions use the PGDATA environment variable. Refer to APPENDIX-F for instructions on configuring PGDATA and APPENDIX-I for PGLOG.

To verify that system denies are logged when unprivileged users attempt to change database configuration, as the database administrator (shown here as "postgres"), run the following commands:

$ sudo su - postgres
$ psql

Create a role with no privileges, change the current role to that user, and attempt to change a configuration by running the following SQL:

CREATE ROLE bob;
SET ROLE bob;
SET pgaudit.role='"'"'test'"'"';
RESET ROLE;
DROP ROLE bob;

Check ${PGLOG?} (use the latest log):

$ cat ${PGDATA?}/${PGLOG?}/postgresql-Thu.log
< 2024-01-28 17:57:34.092 UTC bob postgres: >ERROR: permission denied to set parameter "pgaudit.role"
< 2024-01-28 17:57:34.092 UTC bob postgres: >STATEMENT: SET pgaudit.role='"'"'test'"'"';

If the denial is not logged, this is a finding.

By default PostgreSQL configuration files are owned by the Postgres user and cannot be edited by nonprivileged users:

$ ls -la ${PGDATA?} | grep postgresql.conf
-rw-------. 1 postgres postgres 21758 Jan 22 10:27 postgresql.conf

If postgresql.conf is not owned by the database owner and does not have read and write permissions for the owner, this is a finding.'

    desc 'fix', 'Enable logging.

    All denials are logged by default if logging is enabled. To ensure logging is enabled, see the instructions in the supplementary content APPENDIX-C.'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000381-DB-000361"
    tag gid: "V-261925"
    tag rid: "SV-261925r1000780_rule"
    tag stig_id: "CD16-00-007900"
    tag fix_id: "F-65687r1000779_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Without auditing the enforcement of access restrictions against changes to configuration, it would be difficult to identify attempted attacks and an audit trail would not be available for forensic investigation for after-the-fact actions. 

    Enforcement actions are the methods or mechanisms used to prevent unauthorized changes to configuration settings. Enforcement action methods may be as simple as denying access to a file based on the application of file permissions (access restriction). Audit items may consist of lists of actions blocked by access restrictions or changes identified after the fact.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end