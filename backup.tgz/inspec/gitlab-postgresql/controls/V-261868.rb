control "V-261868" do
    title "SRG-APP-000097-DB-000041"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'As the database administrator (shown here as "postgres"), check the current log_line_prefix setting by running the following SQL:

$ sudo su - postgres
$ psql -c "SHOW log_line_prefix"

If log_line_prefix does not contain "%m %u %d %s", this is a finding.'

    desc 'fix', '$ sudo su - postgres
    $ vi ${PGDATA?}/postgresql.conf

    Extra parameters can be added to the setting log_line_prefix to log application related information:

    # %a = application name
    # %u = user name
    # %d = database name
    # %r = remote host and port
    # %p = process ID
    # %m = timestamp with milliseconds
    # %i = command tag
    # %s = session startup
    # %e = SQL state

    For example:

    log_line_prefix = '"'"'< %m %a %u %d %r %p %i %e %s>'"'"'

    As the system administrator, reload the server with the new configuration:

    $ sudo systemctl reload postgresql-${PGVER?}'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000097-DB-000041"
    tag gid: "V-261868"
    tag rid: "SV-261868r1000609_rule"
    tag stig_id: "CD16-00-001200"
    tag fix_id: "F-65630r1000608_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Information system auditing capability is critical for accurate forensic analysis. Without establishing where events occurred, it is impossible to establish, correlate, and investigate the events relating to an incident.

    In order to compile an accurate risk assessment and provide forensic analysis, it is essential for security personnel to know where events occurred, such as application components, modules, session identifiers, filenames, host names, and functionality. 

    Associating information about where the event occurred within the application provides a means of investigating an attack; recognizing resource utilization or capacity thresholds; or identifying an improperly configured application.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end