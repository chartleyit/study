control "V-261924" do
    title "SRG-APP-000380-DB-000360"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'To list all the permissions of individual roles, as the database administrator (shown here as "postgres"), run the following SQL:

$ sudo su - postgres
$ psql -c "\du"

If any role has SUPERUSER that should not, this is a finding.

List all the permissions of databases and schemas by running the following SQL:

$ sudo su - postgres
$ psql -c "\l"
$ psql -c "\dn+"

If any database or schema has update ("W") or create ("C") privileges and should not, this is a finding.'

    desc 'fix', 'Configure PostgreSQL to enforce access restrictions associated with changes to the configuration of PostgreSQL or database(s).

    Use ALTER ROLE to remove accesses from roles:

    $ psql -c "ALTER ROLE <role_name> NOSUPERUSER"

    Use REVOKE to remove privileges from databases and schemas:

    $ psql -c "REVOKE ALL PRIVILEGES ON <table> FROM <role_name>"'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000380-DB-000360"
    tag gid: "V-261924"
    tag rid: "SV-261924r1000777_rule"
    tag stig_id: "CD16-00-007800"
    tag fix_id: "F-65686r1000776_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Failure to provide logical access restrictions associated with changes to configuration may have significant effects on the overall security of the system.

    When dealing with access restrictions pertaining to change control, it should be noted that any changes to the hardware, software, and/or firmware components of the information system can potentially have significant effects on the overall security of the system.

    Accordingly, only qualified and authorized individuals should be allowed to obtain access to system components for the purposes of initiating changes, including upgrades and modifications.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end