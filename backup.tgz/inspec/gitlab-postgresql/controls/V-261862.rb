control "V-261862" do
    title "SRG-APP-000090-DB-000065"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Note: The following instructions use the PGDATA environment variable. Refer to APPENDIX-F for instructions on configuring PGDATA.

Check PostgreSQL settings and documentation to determine whether designated personnel are able to select which auditable events are being audited.

As the database administrator (shown here as "postgres"), verify the permissions for PGDATA:

$ ls -la ${PGDATA?}

If anything in PGDATA is not owned by the database administrator, this is a finding.

As the database administrator, run the following SQL:

$ sudo su - postgres
$ psql -c "\du"

Review the role permissions, if any role is listed as superuser but should not have that access, this is a finding.'

    desc 'fix', 'Configure PostgreSQL'"'"'s settings to allow designated personnel to select which auditable events are audited.

    Using pgaudit allows administrators the flexibility to choose what they log. For an overview of the capabilities of pgaudit, refer to https://github.com/pgaudit/pgaudit. 

    Refer to supplementary content APPENDIX-B for documentation on installing pgaudit.

    Refer to supplementary content APPENDIX-C for instructions on enabling logging. Only administrators/superuser can change PostgreSQL configurations. Access to the database administrator must be limited to designated personnel only.

    To ensure that postgresql.conf is owned by the database owner:

    $ chown postgres:postgres ${PGDATA?}/postgresql.conf
    $ chmod 600 ${PGDATA?}/postgresql.conf'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000090-DB-000065"
    tag gid: "V-261862"
    tag rid: "SV-261862r1000591_rule"
    tag stig_id: "CD16-00-000600"
    tag fix_id: "F-65624r1000590_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Without the capability to restrict which roles and individuals can select which events are audited, unauthorized personnel may be able to prevent or interfere with the auditing of critical events.

    Suppression of auditing could permit an adversary to evade detection.

    Misconfigured audits can degrade the system'"'"'s performance by overwhelming the audit log. Misconfigured audits may also make it more difficult to establish, correlate, and investigate the events relating to an incident or identify those responsible for one.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end