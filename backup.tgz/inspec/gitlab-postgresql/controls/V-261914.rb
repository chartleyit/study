control "V-261914" do
    title "SRG-APP-000328-DB-000301"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'Review system documentation to identify the required discretionary access control (DAC).

Review the security configuration of the database and PostgreSQL. If applicable, review the security configuration of the application(s) using the database.

If the discretionary access control defined in the documentation is not implemented in the security configuration, this is a finding.

If any database objects are found to be owned by users not authorized to own database objects, this is a finding.

To check the ownership of objects in the database, as the database administrator, run the following:

$ sudo su - postgres
$ psql -X -c '"'"'\dnS'"'"'
$ psql -x -c "\dt *.*"
$ psql -X -c '"'"'\dsS'"'"'
$ psql -x -c "\dv *.*"
$ psql -x -c "\df+ *.*"

If any role is given privileges to objects it should not have, this is a finding.'

    desc 'fix', 'Implement the organization'"'"'s DAC policy in the security configuration of the database and PostgreSQL, and, if applicable, the security configuration of the application(s) using the database.

    To GRANT privileges to roles, as the database administrator (shown here as "postgres"), run statements like the following examples:

    $ sudo su - postgres
    $ psql -c "CREATE SCHEMA test"
    $ psql -c "GRANT CREATE ON SCHEMA test TO bob"
    $ psql -c "CREATE TABLE test.test_table(id INT)"
    $ psql -c "GRANT SELECT ON TABLE test.test_table TO bob"

    To REVOKE privileges to roles, as the database administrator (shown here as "postgres"), run statements like the following examples:

    $ psql -c "REVOKE SELECT ON TABLE test.test_table FROM bob"
    $ psql -c "REVOKE CREATE ON SCHEMA test FROM bob"'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000328-DB-000301"
    tag gid: "V-261914"
    tag rid: "SV-261914r1000747_rule"
    tag stig_id: "CD16-00-006700"
    tag fix_id: "F-65676r1000746_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Discretionary Access Control (DAC) is based on the notion that individual users are "owners" of objects and therefore have discretion over who should be authorized to access the object and in which mode (e.g., read or write). Ownership is usually acquired as a consequence of creating the object or via specified ownership assignment. DAC allows the owner to determine who will have access to objects they control. An example of DAC includes user-controlled table permissions.

    When discretionary access control policies are implemented, subjects are not constrained with regard to what actions they can take with information for which they have already been granted access. Thus, subjects that have been granted access to information are not prevented from passing (i.e., the subjects have the discretion to pass) the information to other subjects or objects. 

    A subject that is constrained in its operation by Mandatory Access Control policies is still able to operate under the less rigorous constraints of this requirement. Thus, while Mandatory Access Control imposes constraints preventing a subject from passing information to another subject operating at a different sensitivity level, this requirement permits the subject to pass the information to any subject at the same sensitivity level.

    The policy is bounded by the information system boundary. Once the information is passed outside of the control of the information system, additional means may be required to ensure the constraints remain in effect. While the older, more traditional definitions of discretionary access control require identity-based access control, that limitation is not required for this use of discretionary access control.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end