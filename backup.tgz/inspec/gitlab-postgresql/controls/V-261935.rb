control "V-261935" do
    title "SRG-APP-000454-DB-000389"
    desc '<GroupDescription></GroupDescription>'

    desc 'check', 'To check software installed by packages, as the system administrator, run the following command:

$ sudo rpm -qa | grep postgres

If multiple versions of postgres are installed but are unused, this is a finding.'

    desc 'fix', 'Use package managers (RPM or apt-get) for installing PostgreSQL. Unused software is removed when updated.'

    impact 10.0
    tag severity: "medium"
    tag gtitle: "SRG-APP-000454-DB-000389"
    tag gid: "V-261935"
    tag rid: "SV-261935r1000810_rule"
    tag stig_id: "CD16-00-009100"
    tag fix_id: "F-65697r1000809_fix"
    # tag cci: 
    # tag nist:

    desc "rationale", '<VulnDiscussion>Previous versions of PostgreSQL components that are not removed from the information system after updates have been installed may be exploited by adversaries.

    Some DBMSs'"'"' installation tools may remove older versions of software automatically from the information system. In other cases, manual review and removal will be required. In planning installations and upgrades, organizations must include steps (automated, manual, or both) to identify and remove the outdated modules.

    A transition period may be necessary when both the old and the new software are required. This should be taken into account in the planning.</VulnDiscussion><FalsePositives></FalsePositives><FalseNegatives></FalseNegatives><Documentable>false</Documentable><Mitigations></Mitigations><SeverityOverrideGuidance></SeverityOverrideGuidance><PotentialImpacts></PotentialImpacts><ThirdPartyTools></ThirdPartyTools><MitigationControl></MitigationControl><Responsibility></Responsibility><IAControls></IAControls>'

    # TODO implement describes
end