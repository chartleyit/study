# inspec

## Getting Started

### Prerequisites

- Gitlab Runners
- Gitlab runner connectivity to target_host
- cinc-auditor container image


### Running inspec

Inspec is run via gitlab automation pipelines.  To run an inspec check against a host:

1. Go to **Build > Pipelines**.
![pipelines](images/toolbar-build-pipeline.png)
1. Click **New pipeline**.
1. On the page set the `target_host` value to the host that you are going to scan and provide the `user` and `password`.
![inputs](images/new-pipeline-target-password2.png)
1. Finialize the pipeline and run by clicking on **New pipeline**

### Getting results

Results are stored as artifacts for the pipeline

## Crunchy Data Postgresql 16

These controls are basesd on [crunchy-data-postgresql-16-stig-baseline](https://github.com/mitre/crunchy-data-postgresql-16-stig-baseline) and is intended to be used against both gitlab and postgres16 instances

### inputs

There are a couple of input examples that can be used to validate against different flavors of postgres.