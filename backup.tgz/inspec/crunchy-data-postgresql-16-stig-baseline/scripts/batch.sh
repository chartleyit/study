#!/bin/bash
# ... (populate 'array' as shown above) ...

# readarray -d '' -t controls < <(find controls -type f -name "*.rb" -exec basename {} \; -print0)
# readarray -d '' -t controls < <(find controls -type f -name "*.rb" -printf '%P\0')
readarray -d '' -t controls < <(
    find controls -type f -name "*.rb" -printf '%P\n' | sed 's/\.rb$//' | tr '\n' '\0'
)

batch_size=10 # Number of items per batch

for (( i = 0; i < ${#controls[@]}; i+=batch_size )); do
    batch_items=("${controls[@]:i:batch_size}") # Get a slice of the array
    
    # Example command: echo the batch items
    echo "Processing batch: ${batch_items[*]}" 
    # ./scripts/scan.sh ${batch_items[*]} 

    
    # Replace the above echo with your actual command, e.g.:
    # your_command "${batch_items[@]}" 
done