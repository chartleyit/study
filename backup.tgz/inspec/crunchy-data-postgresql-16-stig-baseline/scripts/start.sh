docker-compose run auditor bash
# EXAMPLES
# cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result.json -t ssh://ansible@10.200.150.68 --controls=SV-26186{0..9} --sudo
# cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result.json --log-level DEBUG -t ssh://chartley@192.168.233.138 --sudo
# exclusion example
# time cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result.json -t ssh://ansible@10.200.150.68 --controls '/^(?!SV-261885$|SV-261859$).*/' --sudo

# time cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result.json -t ssh://ansible@10.200.150.68 --controls SV-261957 --sudo

# time cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result.json -t ssh://ansible@10.200.150.68 --controls '/^(?!SV-261885$|SV-261859$|SV-261964$|SV-261962$).*/' --sudo


# `date %Y%m%d-%H%M`
# time cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result.json -t ssh://ansible@10.200.150.68 --sudo --waiver-file waivers.yml --controls '/^(?!SV-261885$|SV-261859$).*/'
# time cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result.json -t ssh://ansible@10.200.150.68 --sudo --waiver-file waivers.yml --controls SV-261964

# time cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result-`date +%Y%m%d-%H%M`.json -t ssh://ansible@10.200.150.68 --sudo --waiver-file waivers.yml --controls SV-261964
# time cinc-auditor exec ./ --input-file ./inputs_postgres16_gitlab.yml --reporter cli json:./result-`date +%Y%m%d-%H%M`.json -t ssh://ansible@10.200.150.68 --sudo --waiver-file waivers.yml --controls '/^(?!SV-261885$|SV-261859$).*/'
