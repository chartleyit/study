#!/bin/bash

controls=""
if [[ -n "$@" ]]; then
    controls="--controls=$@"
    if [[ "$@" == *"SV-261885"* ]]; then
        echo "excluding SV-261885"
        controls=$(echo "$controls" | sed 's/SV-261885//g')
    fi
fi

set -x
time cinc-auditor exec ./ \
    --input-file ./inputs_postgres16_gitlab.yml \
    --reporter cli json:./result.json \
    --log-level DEBUG \
    --sudo \
    $controls \
    -t ssh://ansible@10.200.150.68