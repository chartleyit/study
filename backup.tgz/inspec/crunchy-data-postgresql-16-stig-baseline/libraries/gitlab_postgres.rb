require "shellwords"

class Lines
    attr_reader :output

    def initialize(raw, desc)
        @output = raw
        @desc = desc
    end

    def lines
        output.split("\n").map(&:strip)
    end

    def to_s
        @desc
    end
end

class PostgresSession < Inspec.resource(1)
    name "postgres_session"
    supports platforms: "ubuntu"
    supports platform: 'almalinux'

    desc "connect to gitlab postgres and run queries"
    example <<-EXAMPLE
        sql = gitlab_postgres('username', 'host', 'port')
        query('sql_query', ['database_name'])

        describe sql.query('SELECT * FROM pg_shadow WHERE passwd IS NULL;') do
            its('output') { should eq '' }
        end
    EXAMPLE

    # sql = postgres_session(input('pg_dba'), input('pg_dba_password'), input('pg_host'), input('pg_port'))
    def initialize(user, pwd, host = nil, port)
        @user = user || "gitlab-psql"
        @host = host || "/var/opt/gitlab/posgresql"
        @port = port || "5432"
        @password = pwd || ""
        # @socket = socket || "/var/opt/gitlab/postgresql/.s.PGSQL.5432"
    end

    def query(query, db = [])
        psql_cmd = create_psql_cmd(query, db)
        # TODO adjust command to run as gitlab-psql
        # inspec.command(psql_cmd)
        # TODO improve error output
        # cmd = inspec.command(psql_cmd, redact_regex: /(PGPASSWORD=').+(' psql .*)/)
        cmd = inspec.command(psql_cmd)
        out = cmd.stdout + "\n" + cmd.stderr
        if cmd.exit_status != 0 || out =~ /could not connect to .*/ || out.downcase =~ /^error:.*/
            Lines.new(out, "PostgreSQL query with errors: #{query}")
        else
            Lines.new(cmd.stdout.strip, "PostgreSQL query: #{query}")
        end
    end

    private

    def escape_string(query)
        Shellwords.escape(query)
    end

    def create_psql_cmd(query, db = [])
        "sudo gitlab-psql #{@user} -A -t -c #{escape_string(query)} #{db}"
    end
end